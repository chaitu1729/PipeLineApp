package com.PipeLine_Automation.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;

public class WeightCalcServlet extends HttpServlet{


	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		System.out.println(request.getParameter("Od"));
		double Od =Double.parseDouble(request.getParameter("Od"));
		double minDepth =Double.parseDouble(request.getParameter("minDepth"))*12;
		double maxDepth =Double.parseDouble(request.getParameter("maxDepth"))*12;
		double intPressure =Double.parseDouble(request.getParameter("IntPressure"));
		double density = Double.parseDouble(request.getParameter("density"))/Math.pow(12, 3);
		String OdUnits=request.getParameter("OdUnit");
		String minDepthUnit = request.getParameter("minDepthUnit");
		String maxDepthUnit = request.getParameter("maxDepthUnit");
		String iPressUnit = request.getParameter("IPressUnit");
		String densityUnit = request.getParameter("densityUnits");
		String matGrade = request.getParameter("matGrade");
		double selectedThickness = Double.parseDouble(request.getParameter("selectedThickness"));
		double corrCoatThickness = Double.parseDouble(request.getParameter("corrCoatThickness"))*0.001;
		double corrCoatDensity = Double.parseDouble(request.getParameter("corrCoatDensity"))/Math.pow(12, 3);
		String corrCoatDensityUnits = request.getParameter("corrCoatDensityUnits");
		double cutBackLength = Double.parseDouble(request.getParameter("cutBackLength"));
		String cutBackLengthUnits = request.getParameter("cutBackLengthUnits");
		double inFillDensity = Double.parseDouble(request.getParameter("inFillDensity"))/Math.pow(12, 3);
		String inFillDensityUnits = request.getParameter("inFillDensityUnits");
		double jointLength = Double.parseDouble(request.getParameter("jointLength"))*12;
		String jointlengthUnits = request.getParameter("jointlengthUnits");
		double wtCoatingTihickness = Double.parseDouble(request.getParameter("wtCoatingTihickness"));
		String wtCoatinUnits = request.getParameter("wtCoatinUnits");
		double wtCoatingDensity = Double.parseDouble(request.getParameter("wtCoatingDensity"))/Math.pow(12, 3);
		String wtCoatingDensityUnits =request.getParameter("wtCoatingDensityUnits");
		double percentAbs = Double.parseDouble(request.getParameter("percentAbs"))/100;
		double minProdDensity = Double.parseDouble(request.getParameter("minProdDensity"))/Math.pow(12, 3);
		String minProdDensityUnits =request.getParameter("minProdDensityUnits");
		double pipeLength = Double.parseDouble(request.getParameter("pipeLength"))*63360;
		String pipeLengthUnits = request.getParameter("pipeLengthUnits");
		double effectiveDiameter = Od+(2*corrCoatThickness)+(2*wtCoatingTihickness);
		double yiedStress = 0;
		double tensileStrength = 0;
		double strain_ins_bending = 0.0015;
		double strain_opr_bending=0.0015;
		HttpSession session = request.getSession(false);
		
		if(matGrade!=null && matGrade.equals("EE"))
		{
			yiedStress = 90000;
			tensileStrength = 104265;
		}
		else if(matGrade!=null && matGrade.equals("FF"))
		{
			yiedStress=65300;
			tensileStrength = 77600;
		}
		else if(matGrade!=null && matGrade.equals("HH"))
		{
			yiedStress=72000;
		    tensileStrength=93948;
		}	
		double youngsModulus = 29000000;
		double corAllowance =   Double.parseDouble(request.getParameter("corAllowance"));
		String corAllUnits = request.getParameter("corAllowanceUnits");
		ArrayList<String> conditions = new ArrayList<String>();
				conditions.add("ins");
				conditions.add("opr");
				conditions.add("Hyd");
				ArrayList<String> Codes = new ArrayList<String>();
				Codes.add("PC");
				Codes.add("PsAPI");
				Codes.add("Burst");
				Codes.add("BuckleProp");
				
				if(OdUnits!=null && OdUnits.equals("mm"))
				{
					Od=Od*0.03937;
				}
					
				if(minDepthUnit!=null && minDepthUnit.equals("mts"))
				{
					minDepth=minDepth*3.281/12;
				}
				if(maxDepthUnit!=null && maxDepthUnit.equals("mts"))
				{
					maxDepth=maxDepth*3.281/12;
				}
				if(iPressUnit!=null && iPressUnit.equals("Pa"))
				{
					intPressure=intPressure*0.000145038;
				}
				if(densityUnit!=null && densityUnit.equals("kcm"))
				{
					density = density*3.613*Math.pow(10, -5)*Math.pow(12, 3);
				}
				if(corAllUnits!=null && corAllUnits.equals("mm"))
				{
					corAllowance = corAllowance*0.03937;
				}

				if(corrCoatDensityUnits!=null && corrCoatDensityUnits.equals("kcm"))
				{
					corrCoatDensity = corrCoatDensity*3.613*Math.pow(10, -5)*Math.pow(12, 3);
				}
				if(inFillDensityUnits!=null && inFillDensityUnits.equals("kcm"))
				{
					inFillDensity = inFillDensity*3.613*Math.pow(10, -5)*Math.pow(12, 3);
				}
				if(wtCoatingDensityUnits!=null && wtCoatingDensityUnits.equals("kcm"))
				{
					wtCoatingDensity = wtCoatingDensity*3.613*Math.pow(10, -5);
				}
				if(minProdDensityUnits!=null && minProdDensityUnits.equals("kcm"))
				{
					minProdDensity = minProdDensity*3.613*Math.pow(10, -5)*Math.pow(12, 3);
				}
		
				if(cutBackLengthUnits!=null && cutBackLengthUnits.equalsIgnoreCase("mm"))
				{
					cutBackLength = cutBackLength*0.03937;	
				}
				if(wtCoatinUnits!=null && wtCoatinUnits.equalsIgnoreCase("mm"))
				{
					wtCoatingTihickness = wtCoatingTihickness*0.03937;	
				}
		
				if(jointlengthUnits!=null && jointlengthUnits.equals("mts"))
				{
					jointLength=jointLength*3.281/12;
				}
				if(pipeLengthUnits!=null && pipeLengthUnits.equals("km"))
				{
					pipeLength=pipeLength*39370.1/63360;
				}
		
		
		double steelDensity = 0.2835648;
		double waterDensity = 0.0371528;
		double Id = (Od-(2*selectedThickness));
		double pipeExtArea = ((Math.PI)/4)*Math.pow(Od, 2);
		double pipeIntArea_new = ((Math.PI)/4)*Math.pow(Id, 2);
		double pipeIntArea_corroded=((Math.PI)/4)*Math.pow((Id+(2*corAllowance)), 2);
		double pipeCsArea_new = pipeExtArea-pipeIntArea_new;
		double pipeCsArea_corroded = pipeExtArea-pipeIntArea_corroded;
		double corrossionCoating_csArea =(Math.PI/4)*(Math.pow(((Od+(2*corrCoatThickness))), 2)-(Math.pow(Od, 2))); 
		double weightCoatingCsArea = (Math.PI/4)*(Math.pow(effectiveDiameter, 2)-Math.pow((Od+(2*corrCoatThickness)), 2));
		double fieldJointInfieldCsArea = (Math.PI/4)*(Math.pow(effectiveDiameter, 2)-Math.pow(Od, 2));
		
		
		
		
		
		double weightPerJoint_new =pipeCsArea_new*jointLength*steelDensity;
		double weightPerJoint_corroded = pipeCsArea_corroded*jointLength*steelDensity;
		double corrossionCoatingweightperJoint = corrossionCoating_csArea*(jointLength-(2*cutBackLength))*corrCoatDensity;
		double concreteweightperJoint = weightCoatingCsArea*(jointLength-(2*cutBackLength))*wtCoatingDensity*(1+(percentAbs));
		double fieldJtInfillWeight = fieldJointInfieldCsArea*2*cutBackLength*inFillDensity;
		double weightOfWaterFlooded_new = pipeIntArea_new*jointLength*waterDensity;
		double weightOfProductPerjoint_unCorr = pipeIntArea_new*jointLength*density;
		double weightOfProductPerjoint_corroded = pipeIntArea_corroded*jointLength*density;
		double minWeightOfintFluidperJoint = pipeIntArea_corroded*jointLength*minProdDensity;
		double buoyancyForce = pipeExtArea*waterDensity*jointLength;
		
		
		
		
		
		double dryWeightPerJoint = weightPerJoint_new+corrossionCoatingweightperJoint+concreteweightperJoint+fieldJtInfillWeight;
		double pipeLineSpeceficGravity_New_Empty = dryWeightPerJoint/buoyancyForce;
		double pipeSubmergedWtPerJoint = dryWeightPerJoint-buoyancyForce;
		double pipeLineDrywtPerunitLength_new_empty = dryWeightPerJoint*12/jointLength;
		double pipeSubmergedWtPerJointPerUnitLength_new_empty = pipeSubmergedWtPerJoint*12/jointLength;
		
		
		
		
		double pipeLineDryweightPerjoint_new_flooded = (weightPerJoint_new+weightOfWaterFlooded_new+concreteweightperJoint+corrossionCoatingweightperJoint+fieldJtInfillWeight);
		double pipelineSpeceficGravity_new_flooded = pipeLineDryweightPerjoint_new_flooded/buoyancyForce;
		double pipeSubmergedWtPerJoint_new_flooded = pipeLineDryweightPerjoint_new_flooded-buoyancyForce;
		double pipeLineDrywtPerunitLength_new_flooded = pipeLineDryweightPerjoint_new_flooded*12/jointLength;
		double pipeLineSubmergedwtPerunitLength_new_flooded = pipeSubmergedWtPerJoint_new_flooded*12/jointLength;
		
		
		
		
		
		
		double pipelinedryWtPerJoint_uncorr_operational = (weightPerJoint_new+weightOfProductPerjoint_unCorr+concreteweightperJoint+corrossionCoatingweightperJoint+fieldJtInfillWeight);
		double pipeLinespeceficGravity_uncorr_operational = pipelinedryWtPerJoint_uncorr_operational/buoyancyForce;
		double pipelineDryWtGravity_uncorr_operational_perUnitLength = pipelinedryWtPerJoint_uncorr_operational*12/jointLength;
		double pipelineSubmergedWt_Uncorr_Oprerational = pipelinedryWtPerJoint_uncorr_operational - buoyancyForce;
		double pipelinedryWtPerJoint_uncorr_operational_perUnit_Len = pipelinedryWtPerJoint_uncorr_operational*12/jointLength;
		double pipelineSubmergedWtPerJoint_uncorr_operational_perUnit_Len = pipelineSubmergedWt_Uncorr_Oprerational*12/jointLength;
		
		
		
		
		
		double pipelineDryWeight_perJoint_corroded_operation = weightOfProductPerjoint_corroded+weightPerJoint_corroded+corrossionCoatingweightperJoint+concreteweightperJoint+fieldJtInfillWeight;
		double pipeLineSpeceficGravity_corroded_operation = pipelineDryWeight_perJoint_corroded_operation/buoyancyForce;
		double pipeLineSubmergedwt_corroded_operational = pipelineDryWeight_perJoint_corroded_operation-buoyancyForce;
		double pipelineDryWeight_perJoint_corroded_operation_perUnit_length = pipelineDryWeight_perJoint_corroded_operation*12/jointLength;
		double pipelineSubmergedWeight_perJoint_corroded_operation_perUnit_length = pipeLineSubmergedwt_corroded_operational*12/jointLength;
		
		
		
		
		
		
		double pipelineDryWtPrJointCorroded_min_contentDensity = weightPerJoint_corroded+corrossionCoatingweightperJoint+concreteweightperJoint+minWeightOfintFluidperJoint;
		double pipelineSpeceficGravityCorroded_min_contentDensity = pipelineDryWtPrJointCorroded_min_contentDensity/buoyancyForce;
		double pipelineSubmergedWtWtPrJointCorroded_min_contentDensity = pipelineDryWtPrJointCorroded_min_contentDensity-buoyancyForce;
		double pipelineDryWtPrJointCorroded_min_contentDensity_per_Unit_length = pipelineDryWtPrJointCorroded_min_contentDensity*12/jointLength;
		double pipelinesubmergedWtPrJointCorroded_min_contentDensity_per_Unit_length = pipelineSubmergedWtWtPrJointCorroded_min_contentDensity*12/jointLength;
		
		
		
		
		
		
		
		double totalPipelineDryWeight_new_Empty = pipeLineDrywtPerunitLength_new_empty*pipeLength/12;
		double totalPipelineSubmergedWeight_new_Empty = pipeSubmergedWtPerJointPerUnitLength_new_empty*pipeLength/12;
		double totalPipelineDryWeight_new_flooded = pipeLineDrywtPerunitLength_new_flooded*pipeLength/12;
		double totalPipelineSubmergedWeight_flooded = pipeLineSubmergedwtPerunitLength_new_flooded*pipeLength/12;
		double totalPipelineDryWeight_uncorroded_operational = pipelinedryWtPerJoint_uncorr_operational_perUnit_Len*pipeLength/12;
		double totalPipelineSubmergedWeight_uncorroded_operational = pipelineSubmergedWtPerJoint_uncorr_operational_perUnit_Len*pipeLength/12;
		double totalPipelineDryWeight_corroded_operational = pipelineDryWeight_perJoint_corroded_operation_perUnit_length*pipeLength/12;
		double totalPipelineSubmergedWeight_corroded_operational = pipelineSubmergedWeight_perJoint_corroded_operation_perUnit_length*pipeLength/12;
		double totalpipelineDryWeight_corroded_min_contents = pipelineDryWtPrJointCorroded_min_contentDensity_per_Unit_length*pipeLength/12;
		double totalpipelineSubmergedWeight_corroded_min_contents = pipelinesubmergedWtPrJointCorroded_min_contentDensity_per_Unit_length*pipeLength/12;
		
		Map<String,TreeMap<String,Double>> pipeWeightsInAllCases = new TreeMap<String, TreeMap<String,Double>>(
			new Comparator<String>() {

				@Override
				public int compare(String o1, String o2) {
					// TODO Auto-generated method stub
					return o1.compareTo(o2);
				}
			}
		);
		
		TreeMap<String,Double> Weights = new TreeMap<String, Double>(
				new Comparator<String>() {

					@Override
					public int compare(String o1, String o2) {
						// TODO Auto-generated method stub
						return o1.compareTo(o2);
					}
				}
			);
		
		Weights.put("Specefic Gravity", pipeLineSpeceficGravity_New_Empty);
		Weights.put("Submerged Weight per Unit Length (lbf/ft)", pipeSubmergedWtPerJointPerUnitLength_new_empty);
		Weights.put("Dry Weight per Unit Length (lbf/ft)", pipeLineDrywtPerunitLength_new_empty);
		Weights.put("Total submerged Weight (kip)",(totalPipelineSubmergedWeight_new_Empty/1000));
		Weights.put("Total Dry Weight (kip)",(totalPipelineDryWeight_new_Empty/1000));
		
		pipeWeightsInAllCases.put("Installation", Weights);
		Weights=new TreeMap<String, Double>();

		Weights.put("Specefic Gravity", pipelineSpeceficGravity_new_flooded);
		Weights.put("Submerged Weight per Unit Length (lbf/ft)", pipeLineSubmergedwtPerunitLength_new_flooded);
		Weights.put("Dry Weight per Unit Length (lbf/ft)", pipeLineDrywtPerunitLength_new_flooded);
		Weights.put("Total submerged Weight (kip)",(totalPipelineSubmergedWeight_flooded/1000));
		Weights.put("Total Dry Weight (kip)",(totalPipelineDryWeight_new_flooded/1000));
		
		pipeWeightsInAllCases.put("Flooded/Hydrotest", Weights);
		Weights=new TreeMap<String, Double>();
		
	
		Weights.put("Specefic Gravity", pipeLinespeceficGravity_uncorr_operational);
		Weights.put("Submerged Weight per Unit Length (lbf/ft)", pipelineSubmergedWtPerJoint_uncorr_operational_perUnit_Len);
		Weights.put("Dry Weight per Unit Length (lbf/ft)", pipelinedryWtPerJoint_uncorr_operational_perUnit_Len);
		Weights.put("Total submerged Weight (kip)",(totalPipelineSubmergedWeight_uncorroded_operational/1000));
		Weights.put("Total Dry Weight (kip)",(totalPipelineDryWeight_uncorroded_operational/1000));
		
		pipeWeightsInAllCases.put("Operational/Uncorroded", Weights);
		Weights=new TreeMap<String, Double>();
		
		
		Weights.put("Specefic Gravity", pipeLineSpeceficGravity_corroded_operation);
		Weights.put("Submerged Weight per Unit Length (lbf/ft)", pipelineSubmergedWeight_perJoint_corroded_operation_perUnit_length);
		Weights.put("Dry Weight per Unit Length (lbf/ft)", pipelineDryWeight_perJoint_corroded_operation_perUnit_length);
		Weights.put("Total submerged Weight (kip)",(totalPipelineSubmergedWeight_corroded_operational/1000));
		Weights.put("Total Dry Weight (kip)",(totalPipelineDryWeight_corroded_operational/1000));
		
		pipeWeightsInAllCases.put("Operational/Corroded", Weights);
		Weights=new TreeMap<String, Double>();
		
		
		Weights.put("Specefic Gravity", pipelineSpeceficGravityCorroded_min_contentDensity);
		Weights.put("Submerged Weight per Unit Length (lbf/ft)", pipelinesubmergedWtPrJointCorroded_min_contentDensity_per_Unit_length);
		Weights.put("Dry Weight per Unit Length (lbf/ft)", pipelineDryWtPrJointCorroded_min_contentDensity_per_Unit_length);
		Weights.put("Total submerged Weight (kip)",(totalpipelineSubmergedWeight_corroded_min_contents/1000));
		Weights.put("Total Dry Weight (kip)",(totalpipelineDryWeight_corroded_min_contents/1000));
		
		pipeWeightsInAllCases.put("Corroded minimum Contents", Weights);
		
		
		if(session!=null)
		{
			session.setAttribute("thickness",selectedThickness);
			session.setAttribute("SG_Ins", pipeLineSpeceficGravity_New_Empty);
			session.setAttribute("Sub_wt_unit_len_Ins", pipeSubmergedWtPerJointPerUnitLength_new_empty);
			session.setAttribute("Dry_wt_unit_len_Ins", pipeLineDrywtPerunitLength_new_empty);
			session.setAttribute("total_sub_wt_ins", totalPipelineSubmergedWeight_new_Empty/1000);
			session.setAttribute("total_dry_wt_ins", totalPipelineDryWeight_new_Empty/1000);
			
			
			session.setAttribute("SG_flooded", pipelineSpeceficGravity_new_flooded);
			session.setAttribute("Sub_wt_unit_len_flooded", pipeLineSubmergedwtPerunitLength_new_flooded);
			session.setAttribute("Dry_wt_unit_len_flooded", pipeLineDrywtPerunitLength_new_flooded);
			session.setAttribute("total_sub_wt_floodeed", (totalPipelineSubmergedWeight_flooded/1000));
			session.setAttribute("total_dry_wt_flooded",(totalPipelineDryWeight_new_flooded/1000));
			
			
			session.setAttribute("SG_Opr_Unc", pipeLinespeceficGravity_uncorr_operational);
			session.setAttribute("Sub_wt_unit_len_Opr_Unc", pipelineSubmergedWtPerJoint_uncorr_operational_perUnit_Len);
			session.setAttribute("Dry_wt_unit_len_Opr_Unc", pipelinedryWtPerJoint_uncorr_operational_perUnit_Len);
			session.setAttribute("total_sub_wt_Opr_Unc", (totalPipelineSubmergedWeight_uncorroded_operational/1000));
			session.setAttribute("total_dry_wt_Opr_Unc",(totalPipelineDryWeight_uncorroded_operational/1000));
			
			
			
			session.setAttribute("SG_Opr_Cor", pipeLineSpeceficGravity_corroded_operation);
			session.setAttribute("Sub_wt_unit_len_Opr_Cor", pipelineSubmergedWeight_perJoint_corroded_operation_perUnit_length);
			session.setAttribute("Dry_wt_unit_len_Opr_Cor", pipelineDryWeight_perJoint_corroded_operation_perUnit_length);
			session.setAttribute("total_sub_wt_Opr_Cor", (totalPipelineSubmergedWeight_corroded_operational/1000));
			session.setAttribute("total_dry_wt_Opr_Cor",(totalPipelineDryWeight_corroded_operational/1000));
			
			
			session.setAttribute("SG_Cor_Min_contents", pipelineSpeceficGravityCorroded_min_contentDensity);
			session.setAttribute("Sub_wt_unit_len_Cor_Min_contents", pipelinesubmergedWtPrJointCorroded_min_contentDensity_per_Unit_length);
			session.setAttribute("Dry_wt_unit_len_Cor_Min_contents", pipelineDryWtPrJointCorroded_min_contentDensity_per_Unit_length);
			session.setAttribute("total_sub_wt_Cor_Min_contents", (totalpipelineSubmergedWeight_corroded_min_contents/1000));
			session.setAttribute("total_dry_wt_Cor_Min_contents",(totalpipelineDryWeight_corroded_min_contents/1000));
			
			session.setAttribute("Eff_diameter", effectiveDiameter);
			session.setAttribute("Id", Id);
			
			
			
		}
		
		ArrayList<Map<String, TreeMap<String, Double>>> list = new ArrayList<Map<String,TreeMap<String,Double>>>();
		list.add(pipeWeightsInAllCases);
		JSONArray jArray = new JSONArray();
		jArray.put(list);
		PrintWriter out = response.getWriter();
		out.println(jArray);
		System.out.println(jArray);
		
		
		
}
}
