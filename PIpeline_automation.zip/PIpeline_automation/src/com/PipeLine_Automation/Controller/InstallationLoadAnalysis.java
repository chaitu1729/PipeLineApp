package com.PipeLine_Automation.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.PipeLine_Automation.Model.InstallationAnalysisModel;

public class InstallationLoadAnalysis extends HttpServlet {

	@Override
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession(false);
		Double Id = (Double)session.getAttribute("Id");
		Double Od = (Double)session.getAttribute("Od");
		Double straunIns = (Double) session.getAttribute("insBendingStrain");
		Double yieldStress = (Double) session.getAttribute("yieldStress");
		Double youngsMod = (Double) session.getAttribute("youngsModulus");
		Double maxDepth = (Double) session.getAttribute("maxDepth");
		Double thickness = (Double) session.getAttribute("thickness");
		Double submeregdWt = (Double) session.getAttribute("Sub_wt_unit_len_Ins")/12;
		double pipeCsa = Math.PI*((Math.pow(Od, 2))-(Math.pow(Id, 2)))/4;
		double c8=0;
		Double layAngle =  Double.parseDouble(request.getParameter("layAngle"))*0.0174533;
		Double sfIns =  Double.parseDouble(request.getParameter("sfIns"));
		Double insPress =  Double.parseDouble(request.getParameter("insPress"));
		
		double waterDensity = 0.03715;
		double I = Math.PI*((Math.pow(Od, 4))-(Math.pow(Id, 4)))/64;
		double delLay = ((1/Math.cos(layAngle))-1)/(maxDepth/12); //in 1/ft
		
		InstallationAnalysisModel iModel = new InstallationAnalysisModel();
		double Ljlay = iModel.atanh(Math.sin(layAngle))/delLay;
		double c7 = -1/delLay;
		ArrayList<Double> yxList = new ArrayList<Double>();
		double x=0;
		JSONObject jsonObj = new JSONObject();
		JSONObject jsonObj1 = new JSONObject();
		JSONArray jArray  = new JSONArray();
		ArrayList<JSONObject> jobjList = new ArrayList<JSONObject>();
		ArrayList<JSONObject> jobjList1 = new ArrayList<JSONObject>();
		ArrayList<Double> vMisesList = new ArrayList<Double>();
		ArrayList<Double> xList = new ArrayList<Double>();
		ArrayList<ArrayList<Double>> finalList = new ArrayList<ArrayList<Double>>();
		ArrayList<Double> strainList = new ArrayList<Double>();
		ArrayList<Double> layTensionList = new ArrayList<Double>();
		ArrayList<Double> yieldStressList = new ArrayList<Double>();
		while(x<Ljlay)
		{
		
			double delLay1 = delLay; 
			delLay1=delLay1/12; //from 1/ft to 1/in
			xList.add(x);
			double yx = (c7+(Math.cosh((delLay*x)+c8)/delLay))*12;
			yxList.add(yx/12);
			double ydashx = (Math.cosh(delLay1*x*12)*Math.sinh(c8))+(Math.sinh(delLay1*x*12)*Math.cosh(c8));
			double ydoubledashx = delLay1*(Math.sqrt((1+(Math.pow(ydashx, 2)))));
			double shearForce = -2*youngsMod*I*(Math.pow(delLay1, 6))*ydashx/(Math.pow(ydoubledashx, 4));
			double shearStress = shearForce/pipeCsa;
			double curvature = Math.pow(delLay1, 3)/(Math.pow(ydoubledashx, 2));
			double LayTension = submeregdWt*(ydoubledashx)/Math.pow(delLay1, 2);
			double tensileStress = LayTension/pipeCsa;
			double bendingMoment = youngsMod*I*curvature;
			double bendingStress = (bendingMoment*Od)/(I*2);
			double bendingStrain = bendingStress/youngsMod;
			double longitudinalStress = bendingStress+tensileStress;
			double hoopStress = 0;
			strainList.add(bendingStrain);
			layTensionList.add(LayTension);
			if((Od/thickness)>15)
			{
				
				hoopStress=(insPress-(waterDensity*(maxDepth-yx)))*Od/(2*thickness);
			}
			else{
				hoopStress=(insPress-(waterDensity*(maxDepth-yx)))*(((Math.pow(Od, 2))+Math.pow(Id, 2))/((Math.pow(Od, 2))-Math.pow(Id, 2)));
			}
			double vonMises = Math.sqrt((Math.pow(hoopStress, 2))+Math.pow(longitudinalStress, 2) - ((hoopStress*longitudinalStress))+(3*Math.pow(shearStress, 2)));
			vMisesList.add(vonMises/1000);
			double allowableVmises = sfIns*yieldStress;
			yieldStressList.add(yieldStress/1000);
			
			x = x+10;
		}
		finalList.add(yxList);
		finalList.add(xList);
		finalList.add(vMisesList);
		finalList.add(strainList);
		finalList.add(layTensionList);
		finalList.add(yieldStressList);
		jArray.put(yxList);
		jArray.put(xList);
		jArray.put(vMisesList);
		jArray.put(strainList);
		jArray.put(layTensionList);
		jArray.put(yieldStressList);
		PrintWriter out = response.getWriter();
		out.print(jArray);	
		System.out.println(jArray);
	}
}
