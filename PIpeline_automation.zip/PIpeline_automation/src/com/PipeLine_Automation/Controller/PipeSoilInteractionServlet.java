/**
 * 
 */
package com.PipeLine_Automation.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;

import com.PipeLine_Automation.Model.PipeSoilInteractionsModel;

/**
 * @author chaitanyavardhan
 *
 */
public class PipeSoilInteractionServlet extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		HttpSession session = request.getSession(false);
		Double Eff_diameter = (Double)session.getAttribute("Eff_diameter");
		Double Sub_wt_unit_len_Ins = (Double) session.getAttribute("Sub_wt_unit_len_Ins");
		Double Sub_wt_unit_len_flooded = (Double) session.getAttribute("Sub_wt_unit_len_flooded");
		Double Sub_wt_unit_len_Opr_Unc = (Double) session.getAttribute("Sub_wt_unit_len_Opr_Unc");
		Double Sub_wt_unit_len_Opr_Cor = (Double) session.getAttribute("Sub_wt_unit_len_Opr_Cor");
		Double Sub_wt_unit_len_Cor_Min_contents = (Double) session.getAttribute("Sub_wt_unit_len_Cor_Min_contents");
		
		
		Double UDShear_Best = Double.parseDouble(request.getParameter("UDShear_Best"))/144;
		String UDShear_BestUnits = request.getParameter("UDShear_BestUnits");
		Double UDShear_Low = Double.parseDouble(request.getParameter("UDShear_Low"))/144;
		String UDShear_LowUnits = request.getParameter("UDShear_LowUnits");
		Double UDShear_Up = Double.parseDouble(request.getParameter("UDShear_Up"))/144;
		String UDShear_UpUnits = request.getParameter("UDShear_UpUnits");	
		Double Sub_unit_wt = Double.parseDouble(request.getParameter("Sub_unit_wt"))/(144*12);
		String Sub_unit_wt_Units = request.getParameter("Sub_unit_wt_Units");
		Double Strength_Sensitivity = Double.parseDouble(request.getParameter("Strength_Sensitivity"));
		Double uncertainity = Double.parseDouble(request.getParameter("uncertainity"));
		Double coatFricFactor = Double.parseDouble(request.getParameter("coatFricFactor"));
		
		if(UDShear_BestUnits!=null && UDShear_BestUnits.equals("ksm"))
		{
			UDShear_Best=(UDShear_Best*144)/(39.3701*39.3701);
		}
		if(UDShear_LowUnits!=null && UDShear_LowUnits.equals("ksm"))
		{
			UDShear_Low=(UDShear_Low*144)/(39.3701*39.3701);
		}
		if(UDShear_UpUnits!=null && UDShear_UpUnits.equals("ksm"))
		{
			UDShear_Up=(UDShear_Up*144)/(39.3701*39.3701);
		}
		
		if(Sub_unit_wt_Units!=null && Sub_unit_wt_Units.equalsIgnoreCase("kcm"))
		{
			Sub_unit_wt=Sub_unit_wt*144*12/(39.3701*39.3701*39.3701);
		}
		
		
		Double layDownFactor[]={2.0,3.0};
		ArrayList<Double> efWeight = new ArrayList<Double>();
		ArrayList<Double> initialEmbedmentBest = new ArrayList<Double>();
		ArrayList<Double> initialEmbedmentLow = new ArrayList<Double>();
		ArrayList<Double> initialEmbedmentHigh = new ArrayList<Double>();
		ArrayList<Double> peakAxialResistanceBest = new ArrayList<Double>();
		ArrayList<Double> peakAxialResistanceMax = new ArrayList<Double>();
		ArrayList<Double> peakAxialResistanceMin = new ArrayList<Double>();
		
		
		ArrayList<Double> strengthUncretainityFactorHigh = new ArrayList<Double>();
		ArrayList<Double> strengthUncretainityFactorLow = new ArrayList<Double>();
		ArrayList<Double> soilStrengthUncretainityFactorHigh = new ArrayList<Double>();
		ArrayList<Double> soilStrengthUncretainityFactorLow = new ArrayList<Double>();
		ArrayList<Double> peakAxialResistanceHigh = new ArrayList<Double>();
		ArrayList<Double> peakAxialResistanceLow = new ArrayList<Double>();
		
		ArrayList<Double> residualAxialResistanceBest = new ArrayList<Double>();
		ArrayList<Double> residualAxialResistanceHigh = new ArrayList<Double>();
		ArrayList<Double> residualAxialResistanceLow = new ArrayList<Double>();
		
			
		
		
		
		
		for(int i=0;i<layDownFactor.length;i++)
		{
		Double temp =  Math.max((layDownFactor[i]*Sub_wt_unit_len_Ins),Sub_wt_unit_len_flooded);
		Double actualMax = Math.max(temp, Sub_wt_unit_len_Opr_Unc);
		efWeight.add(actualMax);
		}
		
	for(int i=0;i<efWeight.size();i++)
	{
		
		Double temp = (Strength_Sensitivity*Eff_diameter/45)*(Math.pow((efWeight.get(i)/(Eff_diameter*UDShear_Best*12)), 2));
		initialEmbedmentBest.add(temp);
		Double temp1 = (Strength_Sensitivity*Eff_diameter/45)*(Math.pow((efWeight.get(i)/(Eff_diameter*UDShear_Up*12)), 2))/uncertainity;
		initialEmbedmentLow.add(temp1);
		Double temp2 = (Strength_Sensitivity*Eff_diameter/45)*(Math.pow((efWeight.get(i)/(Eff_diameter*UDShear_Low*12)), 2))*uncertainity;
		initialEmbedmentHigh.add(temp2);
	}
		
		for(int i=0;i<initialEmbedmentBest.size();i++)
		{
			if(initialEmbedmentBest.get(i)<=(Eff_diameter/2))
			{
				peakAxialResistanceBest.add(UDShear_Best*Eff_diameter*(Math.acos((1-(2*initialEmbedmentBest.get(i)/Eff_diameter))))*coatFricFactor*12);
			}
			else{
				peakAxialResistanceBest.add((Math.PI)*UDShear_Best*Eff_diameter*coatFricFactor*12/2);
			}
		}
		
		for(int i=0;i<initialEmbedmentHigh.size();i++)
		{
			if(initialEmbedmentHigh.get(i)<=(Eff_diameter/2))
			{
				peakAxialResistanceMax.add(UDShear_Up*Eff_diameter*(Math.acos((1-(2*initialEmbedmentHigh.get(i)/Eff_diameter))))*coatFricFactor*12);
			}
			else{
				peakAxialResistanceMax.add((Math.PI)*UDShear_Up*Eff_diameter*coatFricFactor*12/2);
			}
		}
		
		for(int i=0;i<initialEmbedmentLow.size();i++)
		{
			if(initialEmbedmentLow.get(i)<=(Eff_diameter/2))
			{
				peakAxialResistanceMin.add(UDShear_Low*Eff_diameter*(Math.acos((1-(2*initialEmbedmentLow.get(i)/Eff_diameter))))*coatFricFactor*12);
			}
			else{
				peakAxialResistanceMin.add((Math.PI)*UDShear_Low*Eff_diameter*coatFricFactor*12/2);
			}
		}
		
		for(int i=0;i<peakAxialResistanceMax.size();i++)
		{
			strengthUncretainityFactorHigh.add((peakAxialResistanceMax.get(i)/peakAxialResistanceBest.get(i)));
			strengthUncretainityFactorLow.add((peakAxialResistanceBest.get(i)/peakAxialResistanceMin.get(i)));
		}
		for(int i=0;i<strengthUncretainityFactorHigh.size();i++)
		{
			double a = Math.log(uncertainity);
			double b = Math.log10(uncertainity);
			double b1 = Math.log1p(uncertainity);
			
			
			
			
			soilStrengthUncretainityFactorHigh.add(Math.exp(Math.sqrt((Math.pow(Math.log(uncertainity),2)+(Math.pow(Math.log(strengthUncretainityFactorHigh.get(i)),2))))));
			soilStrengthUncretainityFactorLow.add(Math.exp(Math.sqrt((Math.pow(Math.log(uncertainity),2)+(Math.pow(Math.log(strengthUncretainityFactorLow.get(i)),2))))));
		}
		for(int i=0;i<soilStrengthUncretainityFactorHigh.size();i++)
		{
			peakAxialResistanceHigh.add(soilStrengthUncretainityFactorHigh.get(i)*peakAxialResistanceBest.get(i));
			peakAxialResistanceLow.add(peakAxialResistanceBest.get(i)/(soilStrengthUncretainityFactorLow.get(i)));
		}
		for(int i=0;i<peakAxialResistanceBest.size();i++)
		{
			residualAxialResistanceBest.add(peakAxialResistanceBest.get(i)/(Strength_Sensitivity));
			residualAxialResistanceHigh.add(peakAxialResistanceHigh.get(i)/(Strength_Sensitivity));
			residualAxialResistanceLow.add(peakAxialResistanceLow.get(i)/(Strength_Sensitivity));
		}
		
		Double G_Best=UDShear_Best/(Sub_unit_wt*Eff_diameter);
		Double G_Low=UDShear_Low/(Sub_unit_wt*Eff_diameter);
		Double G_High=UDShear_Up/(Sub_unit_wt*Eff_diameter);
		
		
		PipeSoilInteractionsModel pModel = new PipeSoilInteractionsModel();
		
		TreeMap <String,TreeMap <String,ArrayList<Double>>> axialFricFactors = new TreeMap<String, TreeMap<String,ArrayList<Double>>>();
		TreeMap <String,TreeMap <String,ArrayList<Double>>> lateralFricFactors = new TreeMap<String, TreeMap<String,ArrayList<Double>>>();
		
		
		
		TreeMap <String,TreeMap <String,ArrayList<Double>>> installationFrictionFac_axial = pModel.getAxialFricFactors(peakAxialResistanceBest, peakAxialResistanceHigh, peakAxialResistanceLow, residualAxialResistanceBest, residualAxialResistanceHigh, residualAxialResistanceLow, Sub_wt_unit_len_Ins, "Installation");
		TreeMap <String,TreeMap <String,ArrayList<Double>>> floodedFrictionFac_axial = pModel.getAxialFricFactors(peakAxialResistanceBest, peakAxialResistanceHigh, peakAxialResistanceLow, residualAxialResistanceBest, residualAxialResistanceHigh, residualAxialResistanceLow, Sub_wt_unit_len_flooded, "Flooded");
		TreeMap <String,TreeMap <String,ArrayList<Double>>> operationFrictionFac_corroded_axial = pModel.getAxialFricFactors(peakAxialResistanceBest, peakAxialResistanceHigh, peakAxialResistanceLow, residualAxialResistanceBest, residualAxialResistanceHigh, residualAxialResistanceLow, Sub_wt_unit_len_Opr_Cor, "Operational-Corroded");
		TreeMap <String,TreeMap <String,ArrayList<Double>>> operationFrictionFac_Uncorroded_axial = pModel.getAxialFricFactors(peakAxialResistanceBest, peakAxialResistanceHigh, peakAxialResistanceLow, residualAxialResistanceBest, residualAxialResistanceHigh, residualAxialResistanceLow, Sub_wt_unit_len_Opr_Unc, "Operational-Un Corroded");
		TreeMap <String,TreeMap <String,ArrayList<Double>>> operationFrictionFac_minContents_axial = pModel.getAxialFricFactors(peakAxialResistanceBest, peakAxialResistanceHigh, peakAxialResistanceLow, residualAxialResistanceBest, residualAxialResistanceHigh, residualAxialResistanceLow, Sub_wt_unit_len_Cor_Min_contents, "Corroded Minimum Contents");
		TreeMap <String,TreeMap <String,ArrayList<Double>>> installationFrictionFac_lat = pModel.getLateralFricFactors(initialEmbedmentBest, initialEmbedmentHigh, initialEmbedmentLow, Sub_wt_unit_len_Ins, G_Best, G_High, G_Low, Eff_diameter, uncertainity, Strength_Sensitivity, "Installation", UDShear_Best, UDShear_Low, UDShear_Up);
		TreeMap <String,TreeMap <String,ArrayList<Double>>> floodedFrictionFac_lat = pModel.getLateralFricFactors(initialEmbedmentBest, initialEmbedmentHigh, initialEmbedmentLow, Sub_wt_unit_len_flooded, G_Best, G_High, G_Low, Eff_diameter, uncertainity, Strength_Sensitivity, "Flooded", UDShear_Best, UDShear_Low, UDShear_Up);
		TreeMap <String,TreeMap <String,ArrayList<Double>>> operationFrictionFac_corroded_lat = pModel.getLateralFricFactors(initialEmbedmentBest, initialEmbedmentHigh, initialEmbedmentLow, Sub_wt_unit_len_Opr_Cor, G_Best, G_High, G_Low, Eff_diameter, uncertainity, Strength_Sensitivity, "Operational-Corroded", UDShear_Best, UDShear_Low, UDShear_Up);
		TreeMap <String,TreeMap <String,ArrayList<Double>>> operationFrictionFac_Uncorroded_lat = pModel.getLateralFricFactors(initialEmbedmentBest, initialEmbedmentHigh, initialEmbedmentLow, Sub_wt_unit_len_Opr_Unc, G_Best, G_High, G_Low, Eff_diameter, uncertainity, Strength_Sensitivity, "Operational-Un Corroded", UDShear_Best, UDShear_Low, UDShear_Up);
		TreeMap <String,TreeMap <String,ArrayList<Double>>> operationFrictionFac_minContents_lat = pModel.getLateralFricFactors(initialEmbedmentBest, initialEmbedmentHigh, initialEmbedmentLow, Sub_wt_unit_len_Cor_Min_contents, G_Best, G_High, G_Low, Eff_diameter, uncertainity, Strength_Sensitivity, "Corroded Minimum Contents", UDShear_Best, UDShear_Low, UDShear_Up);
		
		
		axialFricFactors.putAll(installationFrictionFac_axial);
		lateralFricFactors.putAll(installationFrictionFac_lat);
		axialFricFactors.putAll(floodedFrictionFac_axial);
		lateralFricFactors.putAll(floodedFrictionFac_lat);
		axialFricFactors.putAll(operationFrictionFac_corroded_axial);
		lateralFricFactors.putAll(operationFrictionFac_corroded_lat);
		axialFricFactors.putAll(operationFrictionFac_Uncorroded_axial);
		lateralFricFactors.putAll(operationFrictionFac_Uncorroded_lat);
		axialFricFactors.putAll(operationFrictionFac_minContents_axial);
		lateralFricFactors.putAll(operationFrictionFac_minContents_lat);
		
		ArrayList<TreeMap <String,TreeMap <String,ArrayList<Double>>>> jArrayList = new ArrayList<TreeMap<String,TreeMap<String,ArrayList<Double>>>>();
		jArrayList.add(axialFricFactors);
		jArrayList.add(lateralFricFactors);
		session.setAttribute("AxialFricFactors", axialFricFactors);
		session.setAttribute("lateralFricFactors", lateralFricFactors);
		JSONArray jArray = new JSONArray();
		jArray.put(jArrayList);
		PrintWriter out = response.getWriter();
		out.println(jArray);
		System.out.println(jArray);
	}
	
	
	
}
