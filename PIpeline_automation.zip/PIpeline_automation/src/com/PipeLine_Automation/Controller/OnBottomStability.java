package com.PipeLine_Automation.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;

import com.PipeLine_Automation.Model.OnBottomStabilityModel;

public class OnBottomStability extends HttpServlet{


	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		// TODO Auto-generated method stub
		double sigHeight10 =  Double.parseDouble(request.getParameter("sigHeight10"));
		String sigHeightUnits10 = request.getParameter("sigHeightUnits10");
		double spectralPeak10 = Double.parseDouble(request.getParameter("spectralPeak10")); 
		double spreadFactor10 =  Double.parseDouble(request.getParameter("spreadFactor10"));
		double curSpeed10 = Double.parseDouble(request.getParameter("curSpeed10"));
		String curSpeedUnits10 = request.getParameter("curSpeedUnits10");
		double curRefHeight10 =  Double.parseDouble(request.getParameter("curRefHeight10"));
		String curRefHeight10Units =   request.getParameter("curRefHeight10Units");
		Double bearing10 =  Double.parseDouble(request.getParameter("bearing10"));	
		double johnSwap10 =  Double.parseDouble(request.getParameter("johnSwap10"));
		
		double sigHeight100 =  Double.parseDouble(request.getParameter("sigHeight100"));
		String sigHeightUnits100 = request.getParameter("sigHeightUnits100");
		double spectralPeak100 = Double.parseDouble(request.getParameter("spectralPeak100")); 
		double spreadFactor100 =  Double.parseDouble(request.getParameter("spreadFactor100"));
		double curSpeed100 = Double.parseDouble(request.getParameter("curSpeed100"));
		String curSpeedUnits100 = request.getParameter("curSpeedUnits100");
		double curRefHeight100 =  Double.parseDouble(request.getParameter("curRefHeight100"));
		String curRefHeight100Units =   request.getParameter("curRefHeight100Units");
		Double bearing100 =  Double.parseDouble(request.getParameter("bearing100"));
		double johnSwap100 =  Double.parseDouble(request.getParameter("johnSwap100"));
		
		double grainSize = Double.parseDouble(request.getParameter("grainSize"));
		String grainSizeUnits = request.getParameter("grainSizeUnits");
		double roughness = Double.parseDouble(request.getParameter("roughness"))*3.2808399;
		
		if(sigHeightUnits10!=null && sigHeightUnits10.equalsIgnoreCase("mts"))
		{
			sigHeight10 = sigHeight10*3.2808399;
		}
		
		if(curRefHeight10Units!=null && curRefHeight10Units.equalsIgnoreCase("mts"))
		{
			curRefHeight10 = curRefHeight10*3.2808399;
		}
		if(sigHeightUnits100!=null && sigHeightUnits100.equalsIgnoreCase("mts"))
		{
			sigHeight100 = sigHeight100*3.2808399;
		}
		
		if(curRefHeight100Units!=null && curRefHeight100Units.equalsIgnoreCase("mts"))
		{
			curRefHeight100 = curRefHeight10*3.28008399;
		}
		
		if(curSpeedUnits10!=null && curSpeedUnits10.equalsIgnoreCase("mts/s"))
		{
		curSpeed10 = curSpeed10*3.2808399;
		}
		if(curSpeedUnits100!=null && curSpeedUnits100.equalsIgnoreCase("mts/s"))
		{
		curSpeed100 = curSpeed100*3.2808399;
		}
		
		OnBottomStabilityModel osmModel = new OnBottomStabilityModel();
		
		HttpSession session = request.getSession(false);
		Double insSubmergedWt = (Double) session.getAttribute("Sub_wt_unit_len_Ins");
		Double Sub_wt_unit_len_Cor_Min_contents = (Double) session.getAttribute("Sub_wt_unit_len_Cor_Min_contents");
		Double density = (Double) session.getAttribute("density");
		Double refDepth = (Double) session.getAttribute("minDepth")/12;
		double Eff_diameter = (Double) session.getAttribute("Eff_diameter")/12;
		double viscWater = 0.0000126;
		
		TreeMap<String, TreeMap<String, Double>> finalMap = new TreeMap<String, TreeMap<String, Double>>();
		TreeMap<String, Double> submapIns = new TreeMap<String, Double>();
		TreeMap<String, Double> submapOpr = new TreeMap<String, Double>();
		finalMap.putAll(osmModel.getData(insSubmergedWt, density, curSpeed10, curRefHeight10, spreadFactor10, bearing10, spectralPeak10, Eff_diameter, 0.61, roughness, grainSize, johnSwap10, sigHeight10, viscWater, "Installation",refDepth));
		finalMap.putAll(osmModel.getData(Sub_wt_unit_len_Cor_Min_contents, density, curSpeed100, curRefHeight100, spreadFactor100, bearing100, spectralPeak100, Eff_diameter, 0.735, roughness, grainSize, johnSwap100, sigHeight100, viscWater, "Operation",refDepth));
		submapIns=finalMap.get("Installation");
		submapOpr=finalMap.get("Operation");
		double insFlag = submapIns.get("Notes");
		double oprFlag = submapOpr.get("Notes");
		String Notes="";
		if(insFlag==1 && oprFlag==1){
			Notes=" * the selected thicnkness(s) are suffucient for Onbottom stability no additional weight is needed.";
		}
		
		else if(insFlag!=1 && oprFlag==1)
		{
			Notes=" * Onbottom stability check failed in installation case additional weight is required please go to the weight calculation tab and increase the concrete thickness.";
		}
		else if(oprFlag!=1 && insFlag==1)
		{
			Notes=" * Onbottom stability check failed in installation case additional weight is required please go to the weight calculation tab and increase the concrete thickness.";
		}
		else if(oprFlag!=1 && insFlag!=1)
		{
			Notes=" * Onbottom stability check failed in both the cases additional weight is required for stability please go to the weight calculation tab and increase the concrete thickness.";
		}
		ArrayList<Map<String, TreeMap<String, Double>>> list = new ArrayList<Map<String,TreeMap<String,Double>>>();
		finalMap.get("Installation").remove("Notes");
		finalMap.get("Operation").remove("Notes");
		session.setAttribute("OnbottomStability", finalMap);
		list.add(finalMap);
		JSONArray jArray = new JSONArray();
		jArray.put(list);
		jArray.put(Notes);
		PrintWriter out = response.getWriter();
		out.println(jArray);
		System.out.println(jArray);
		
	}
	
	

}
