package com.PipeLine_Automation.Controller;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFCellUtil;

public class ExcelResults extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet s = wb.createSheet("WallT");
		wb.setSheetName(0, "HSSF Test");
		HttpSession session = request.getSession(true);
		Map<String, HashMap<String, Double>> totalThickness= (Map<String, HashMap<String, Double>>) session.getAttribute("totalThickness");
		HSSFRow row1 = s.createRow(0);
		HSSFRow row2 = s.createRow(1);
		HSSFRow row3 = s.createRow(2);
		
		int i=0;
		int j=0;
		for(String key:totalThickness.keySet())
		{
			HSSFCell c = HSSFCellUtil.createCell(row1, i, key);			
					
			for(String key2:totalThickness.get(key).keySet())
			{
				HSSFCell c2 = HSSFCellUtil.createCell(row2, j, key2);	
				HSSFCell c3 = HSSFCellUtil.createCell(row3, j, String.valueOf(totalThickness.get(key).get(key2)));	
			}
		}
		ServletOutputStream out = response.getOutputStream();
        wb.write(out);
        out.flush();
        out.close();

        //offer the user the option of opening or downloading the resulting Excel file
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-Disposition", "attachment; filename=MyExcel.xls");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet s = wb.createSheet("WallT");
		wb.setSheetName(0, "HSSF Test");
		HttpSession session = request.getSession(true);
		Map<String, HashMap<String, Double>> totalThickness= (Map<String, HashMap<String, Double>>) session.getAttribute("totalThickness");
		HSSFRow row1 = s.createRow(0);
		HSSFRow row2 = s.createRow(1);
		HSSFRow row3 = s.createRow(2);
		
		int i=0;
		int j=0;
		for(String key:totalThickness.keySet())
		{
			
			HSSFCell c = HSSFCellUtil.createCell(row1, i, key);			
			HSSFCell c4= HSSFCellUtil.createCell(row1, ++i, key);
			for(String key2:totalThickness.get(key).keySet())
			{
				HSSFCell c2 = HSSFCellUtil.createCell(row2, j, key2);	
				HSSFCell c3 = HSSFCellUtil.createCell(row3, j, String.valueOf(totalThickness.get(key).get(key2)));	
			j++;
			}
		i++;
		}

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		wb.write(outByteStream);
		byte [] outArray = outByteStream.toByteArray();
		response.setContentType("application/ms-excel");
		response.setContentLength(outArray.length);
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setHeader("Content-Disposition", "attachment; filename=testxls.xls");
		OutputStream outStream = response.getOutputStream();
		outStream.write(outArray);
		outStream.flush();

        //offer the user the option of opening or downloading the resulting Excel file
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-Disposition", "attachment; filename=MyExcel.xls");

		
	}
}
