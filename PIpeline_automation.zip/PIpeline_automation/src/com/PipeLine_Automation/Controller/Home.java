package com.PipeLine_Automation.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.PipeLine_Automation.Model.Wallthicknesscalculations;

public class Home extends HttpServlet {
	
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		
		System.out.println(request.getParameter("Od"));
		double Od =Double.parseDouble(request.getParameter("Od"));
		double minDepth =Double.parseDouble(request.getParameter("minDepth"))*12;
		double maxDepth =Double.parseDouble(request.getParameter("maxDepth"))*12;
		double intPressure =Double.parseDouble(request.getParameter("IntPressure"));
		double density = Double.parseDouble(request.getParameter("density"))/Math.pow(12, 3);
		String OdUnits=request.getParameter("OdUnit");
		String minDepthUnit = request.getParameter("minDepthUnit");
		String maxDepthUnit = request.getParameter("maxDepthUnit");
		String iPressUnit = request.getParameter("IPressUnit");
		String densityUnit = request.getParameter("densityUnits");
		String matGrade = request.getParameter("matGrade");
		double yiedStress = 0;
		double tensileStrength = 0;
		double strain_ins_bending = 0.0015;
		double strain_opr_bending=0.0015;
		if(matGrade!=null && matGrade.equals("EE"))
		{
			yiedStress = 90000;
			tensileStrength = 104265;
		}
		else if(matGrade!=null && matGrade.equals("FF"))
		{
			yiedStress=65300;
			tensileStrength = 77600;
		}
		else if(matGrade!=null && matGrade.equals("HH"))
		{
			yiedStress=72000;
		    tensileStrength=93948;
		}	
		double youngsModulus = 29000000;
		double corAllowance =   Double.parseDouble(request.getParameter("corAllowance"));
		String corAllUnits = request.getParameter("corAllowanceUnits");
		TreeMap<String, Double> thickness = new TreeMap<String, Double>();
		ArrayList<String> conditions = new ArrayList<String>();
				conditions.add("ins");
				conditions.add("opr");
				conditions.add("Hyd");
				ArrayList<String> Codes = new ArrayList<String>();
				Codes.add("PC");
				Codes.add("PsAPI");
				Codes.add("Burst");
				Codes.add("BuckleProp");
				
				if(OdUnits!=null && OdUnits.equals("mm"))
				{
					Od=Od*0.03937;
				}
					
				if(minDepthUnit!=null && minDepthUnit.equals("mts"))
				{
					minDepth=minDepth*3.281/12;
				}
				if(maxDepthUnit!=null && maxDepthUnit.equals("mts"))
				{
					maxDepth=maxDepth*3.281/12;
				}
				if(iPressUnit!=null && iPressUnit.equals("Pa"))
				{
					intPressure=intPressure*0.000145038;
				}
				if(densityUnit!=null && densityUnit.equals("kcm"))
				{
					density = density*3.613*Math.pow(10, -5)*Math.pow(12, 3);
				}
				if(corAllUnits!=null && corAllUnits.equals("mm"))
				{
					corAllowance = corAllowance*0.03937;
				}
				double airgap = 1200;
				double densityOfTestFluid=0.037153;
				double densityOfWater = 0.037153;
				double ovality=0.0075;
				Wallthicknesscalculations wtc  = new Wallthicknesscalculations();
				Map<String, HashMap<String, Double>> pressureContainment = new HashMap<String, HashMap<String,Double>>();
				Map<String, HashMap<String, Double>> hydroStaticTestPressure = new HashMap<String, HashMap<String,Double>>();
				Map<String, HashMap<String, Double>> asmeB318 = new HashMap<String, HashMap<String,Double>>();
				Map<String, HashMap<String, Double>> intBurst = new HashMap<String, HashMap<String,Double>>();
				Map<String, HashMap<String, Double>> collapseDueToextPressure = new HashMap<String, HashMap<String,Double>>();
				Map<String, HashMap<String, Double>> collapseDueToCombinedBendingAndextPressure = new HashMap<String, HashMap<String,Double>>();
				Map<String, HashMap<String, Double>> bucklePropagation = new HashMap<String, HashMap<String,Double>>();
				pressureContainment = wtc.pressureContainment(intPressure, yiedStress, Od, corAllowance);
				
				hydroStaticTestPressure = wtc.hydrostaticTestPressure(intPressure, yiedStress, Od, corAllowance, airgap, maxDepth, density, densityOfTestFluid);
				asmeB318 = wtc.AsmeB318(intPressure,yiedStress,Od, density, corAllowance, minDepth, maxDepth,densityOfTestFluid);
				intBurst = wtc.internalBurstPressure(intPressure, yiedStress, tensileStrength, minDepth, maxDepth, airgap, density, densityOfTestFluid, corAllowance, Od);
				collapseDueToextPressure = wtc.collapseDueToExternalPressure(intPressure, yiedStress, youngsModulus, minDepth, maxDepth, airgap, density, densityOfWater, corAllowance, Od);
				collapseDueToCombinedBendingAndextPressure = wtc.collapseDueToCombinedBendingExtPressure(yiedStress, youngsModulus, ovality, strain_ins_bending, strain_opr_bending, Od, densityOfWater,density, maxDepth, minDepth,airgap,corAllowance);
				bucklePropagation = wtc.BucklePropagation(yiedStress, youngsModulus, Od, densityOfWater, density, maxDepth, minDepth, airgap, corAllowance);
				Map<String, HashMap<String, Double>> totalThickness = new HashMap<String, HashMap<String,Double>>();
				totalThickness.putAll(pressureContainment);
				totalThickness.putAll(hydroStaticTestPressure);
				totalThickness.putAll(asmeB318);
				totalThickness.putAll(intBurst);
				totalThickness.putAll(collapseDueToextPressure);
				totalThickness.putAll(collapseDueToCombinedBendingAndextPressure);
				List<HashMap<String, Double>> requiredThickness =   new ArrayList<HashMap<String, Double>>(totalThickness.values());
				HashMap<String, Double> maxthickness = new HashMap<String, Double>();
				Map<String,HashMap<String, Double>> selectedThickness = new HashMap<String,HashMap<String, Double>>();
				ArrayList<Double> operation = new ArrayList<Double>();
				ArrayList<Double> installlation = new ArrayList<Double>();
				HashMap<String, Double> maximumSelectedThickness= new HashMap<String, Double>();
				for(int i=0;i<requiredThickness.size();i++)
				{
					maxthickness = requiredThickness.get(i);
					Iterator<Entry<String,Double>> iterator = maxthickness.entrySet().iterator();
					int index=0;
					while (iterator.hasNext()) {
						Map.Entry<String,Double> entry = (Map.Entry<String,Double>) iterator.next();
						if(index%2==0)
						{
							operation.add(entry.getValue());
						}
						else{
							installlation.add(entry.getValue());
						}
						index = index+1;
					}
					
					
				}
				totalThickness.putAll(bucklePropagation);
				Double maxOperationThickness = java.util.Collections.max(operation);
				Double maxInstalllationthickness = java.util.Collections.max(installlation);
				maximumSelectedThickness.put("operation", maxOperationThickness);
				maximumSelectedThickness.put("installation", maxInstalllationthickness);
				selectedThickness.put("Selected thickness",maximumSelectedThickness);
				totalThickness.putAll(selectedThickness);
				HttpSession session = request.getSession(true);
				session.setAttribute("Od", Od);
				session.setAttribute("intPressure", intPressure);
				session.setAttribute("minDepth", minDepth);
				session.setAttribute("maxDepth", maxDepth);
				session.setAttribute("density", density);
				session.setAttribute("corrosionAllowance", corAllowance);
				session.setAttribute("thickness", maxOperationThickness);
				session.setAttribute("yieldStress", yiedStress);
				session.setAttribute("youngsModulus", youngsModulus);
				session.setAttribute("insBendingStrain", strain_ins_bending);
				
				ArrayList<Map<String, HashMap<String, Double>>> list = new ArrayList<Map<String,HashMap<String,Double>>>();
				list.add(totalThickness);
				session.setAttribute("totalThickness", totalThickness);
				JSONArray jArray = new JSONArray();
				jArray.put(list);
				PrintWriter out = response.getWriter();
				out.println(jArray);
				System.out.println(jArray);
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
	
	}
}
