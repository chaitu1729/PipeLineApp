package com.PipeLine_Automation.Model;

import java.util.ArrayList;
import java.util.TreeMap;

public class PipeSoilInteractionsModel {
	
	
	public TreeMap <String,TreeMap <String,ArrayList<Double>>> getAxialFricFactors(ArrayList<Double> peakAxialBest,ArrayList<Double> peakAxialHigh,
			ArrayList<Double> peakAxialLow,ArrayList<Double> residualAxialBest,ArrayList<Double> residualAxialHigh,ArrayList<Double> residualAxialLow,double submeregdWt,String designCase){
		
		TreeMap <String,ArrayList<Double>> fricFacMap = new TreeMap<String, ArrayList<Double>>();
		TreeMap <String,TreeMap <String,ArrayList<Double>>> designCaseMap = new TreeMap<String, TreeMap<String,ArrayList<Double>>>();
		
		ArrayList<Double> peakAxialFricFactorBest=new ArrayList<Double>();
		ArrayList<Double> peakAxialFricFactorHigh=new ArrayList<Double>();
		ArrayList<Double> peakAxialFricFactorLow=new ArrayList<Double>();
		ArrayList<Double> residualAxialFricFactorBest=new ArrayList<Double>();
		ArrayList<Double> residualAxialFricFactorHigh=new ArrayList<Double>();
		ArrayList<Double> residualAxialFricFactorLow=new ArrayList<Double>();
		for(int i=0;i<peakAxialBest.size();i++)
		{
			peakAxialFricFactorBest.add(peakAxialBest.get(i)/submeregdWt);
			peakAxialFricFactorHigh.add(peakAxialHigh.get(i)/submeregdWt);
			peakAxialFricFactorLow.add(peakAxialLow.get(i)/submeregdWt);
			residualAxialFricFactorBest.add(residualAxialBest.get(i)/submeregdWt);
			residualAxialFricFactorHigh.add(residualAxialHigh.get(i)/submeregdWt);
			residualAxialFricFactorLow.add(residualAxialLow.get(i)/submeregdWt);
			
		}
		fricFacMap.put("Peak Axial fiction Factor - Best", peakAxialFricFactorBest);
		fricFacMap.put("Peak Axial fiction Factor - High", peakAxialFricFactorHigh);
		fricFacMap.put("Peak Axial fiction Factor - Low", peakAxialFricFactorLow);
		fricFacMap.put("Residual Axial fiction Factor - Best", residualAxialFricFactorBest);
		fricFacMap.put("Residual Axial fiction Factor - High", residualAxialFricFactorHigh);
		fricFacMap.put("Residual Axial fiction Factor - Low", residualAxialFricFactorLow);
		designCaseMap.put(designCase,fricFacMap);
		
		
	return designCaseMap;
	}
	
	public TreeMap <String,TreeMap <String,ArrayList<Double>>> getLateralFricFactors(ArrayList<Double> initialEmbBest,ArrayList<Double> initialEmbHigh,
			ArrayList<Double> initialEmbLow,Double submeregdWt,double G_Best,double G_High,double G_Low,double eff_diameter,double uncertainity,double Strength_Sensitivity,
			String designCase,double undrainedShearBest,double undrainedShearLow,double undrainedShearUp){

		TreeMap <String,ArrayList<Double>> fricFacMap = new TreeMap<String, ArrayList<Double>>();
		TreeMap <String,TreeMap <String,ArrayList<Double>>> designCaseMap = new TreeMap<String, TreeMap<String,ArrayList<Double>>>();
		ArrayList<Double> peakLateralResistanceBest = new ArrayList<Double>();
		ArrayList<Double> peakLateralResistanceMax = new ArrayList<Double>();
		ArrayList<Double> peakLateralResistanceMin = new ArrayList<Double>();
		ArrayList<Double> shearStrengthUncertainityFac_High = new ArrayList<Double>();
		ArrayList<Double> shearStrengthUncertainityFac_Low = new ArrayList<Double>();
		ArrayList<Double> soilStrengthUncretainityFactorHigh = new ArrayList<Double>();
		ArrayList<Double> soilStrengthUncretainityFactorLow = new ArrayList<Double>();
		ArrayList<Double> peakLateralResistanceHigh = new ArrayList<Double>();
		ArrayList<Double> peakLateralResistanceLow = new ArrayList<Double>();
		ArrayList<Double> residualLateralResistanceBest =  new ArrayList<Double>();
		ArrayList<Double> residualLateralResistanceHigh =  new ArrayList<Double>();
		ArrayList<Double> residualLateralResistanceLow =  new ArrayList<Double>();
		
		
		
		
		
		ArrayList<Double> peakLateralFricFactorBest=new ArrayList<Double>();
		ArrayList<Double> peakLateralFricFactorHigh=new ArrayList<Double>();
		ArrayList<Double> peakLateralFricFactorLow=new ArrayList<Double>();
		ArrayList<Double> residualLateralFricFactorBest=new ArrayList<Double>();
		ArrayList<Double> residualLateralFricFactorHigh=new ArrayList<Double>();
		ArrayList<Double> residualLateralFricFactorLow=new ArrayList<Double>();
		
		
		
		
		
		
		for(int i=0;i<initialEmbBest.size();i++)
		{
			if((initialEmbBest).get(i)<=eff_diameter)
			{
				peakLateralResistanceBest.add((3*undrainedShearBest*initialEmbBest.get(i)*12)/(Math.sqrt(G_Best))+(0.2*submeregdWt));
			}
			else
			{
				peakLateralResistanceBest.add((3*undrainedShearBest*eff_diameter*12)/(Math.sqrt(G_Best))+(0.2*submeregdWt));
			}
		}
		
		for(int i=0;i<initialEmbHigh.size();i++)
		{
			if((initialEmbHigh).get(i)<=eff_diameter)
			{
				peakLateralResistanceMax.add((3*undrainedShearUp*initialEmbHigh.get(i)*12)/(Math.sqrt(G_High))+(0.2*submeregdWt));
			}
			else
			{
				peakLateralResistanceMax.add((3*undrainedShearUp*eff_diameter*12)/(Math.sqrt(G_High))+(0.2*submeregdWt));
			}
		}
		
		for(int i=0;i<initialEmbLow.size();i++)
		{
			if((initialEmbLow).get(i)<=eff_diameter)
			{
				peakLateralResistanceMin.add((3*undrainedShearLow*initialEmbLow.get(i)*12)/(Math.sqrt(G_Low))+(0.2*submeregdWt));
			}
			else
			{
				peakLateralResistanceMin.add((3*undrainedShearLow*eff_diameter*12)/(Math.sqrt(G_Low))+(0.2*submeregdWt));
			}
		}
		
		for(int i=0;i<peakLateralResistanceBest.size();i++)
		{
			shearStrengthUncertainityFac_High.add((peakLateralResistanceMax.get(i)/peakLateralResistanceBest.get(i)));
			shearStrengthUncertainityFac_Low.add((peakLateralResistanceBest.get(i)/peakLateralResistanceMin.get(i)));
		}
		
		for(int i=0;i<shearStrengthUncertainityFac_High.size();i++)
		{
			soilStrengthUncretainityFactorHigh.add(Math.exp(Math.sqrt((Math.pow(Math.log(uncertainity),2)+(Math.pow(Math.log(shearStrengthUncertainityFac_High.get(i)),2))))));
			soilStrengthUncretainityFactorLow.add(Math.exp(Math.sqrt((Math.pow(Math.log(uncertainity),2)+(Math.pow(Math.log(shearStrengthUncertainityFac_Low.get(i)),2))))));
		}
		for(int i=0;i<soilStrengthUncretainityFactorHigh.size();i++)
		{
			
			peakLateralResistanceHigh.add(soilStrengthUncretainityFactorHigh.get(i)*peakLateralResistanceBest.get(i));
			peakLateralResistanceLow.add(peakLateralResistanceBest.get(i)/(soilStrengthUncretainityFactorLow.get(i)));
		}
		for(int i=0;i<peakLateralResistanceBest.size();i++)
		{
			
			residualLateralResistanceBest.add(peakLateralResistanceBest.get(i)/(Strength_Sensitivity));
			residualLateralResistanceHigh.add(peakLateralResistanceHigh.get(i)/(Strength_Sensitivity));
			residualLateralResistanceLow.add(peakLateralResistanceLow.get(i)/(Strength_Sensitivity));
		}
		
		for(int i=0;i<peakLateralResistanceBest.size();i++)
		{
			peakLateralFricFactorBest.add(peakLateralResistanceBest.get(i)/submeregdWt);
			peakLateralFricFactorHigh.add(peakLateralResistanceHigh.get(i)/submeregdWt);
			peakLateralFricFactorLow.add(peakLateralResistanceLow.get(i)/submeregdWt);
			residualLateralFricFactorBest.add(residualLateralResistanceBest.get(i)/submeregdWt);
			residualLateralFricFactorHigh.add(residualLateralResistanceHigh.get(i)/submeregdWt);
			residualLateralFricFactorLow.add(residualLateralResistanceLow.get(i)/submeregdWt);
			
		}
		fricFacMap.put("Peak Lateral fiction Factor - Best", peakLateralFricFactorBest);
		fricFacMap.put("Peak lateral fiction Factor - High", peakLateralFricFactorHigh);
		fricFacMap.put("Peak Lateral fiction Factor - Low", peakLateralFricFactorLow);
		fricFacMap.put("Residual Lateral fiction Factor - Best", residualLateralFricFactorBest);
		fricFacMap.put("Residual Lateral fiction Factor - High", residualLateralFricFactorHigh);
		fricFacMap.put("Residual Lateral fiction Factor - Low", residualLateralFricFactorLow);
		designCaseMap.put(designCase,fricFacMap);
		
		
		
		
		
		
		return designCaseMap;
			}
	}

