package com.PipeLine_Automation.Model;

public class InstallationAnalysisModel {

	public double atanh(double x)
	{
		double val = 0.5*Math.log((x + 1.0) / (-x + 1.0));
		double val1 =  Math.log(1+x);
		double val2 = Math.log(1-x);
	return val;
	}
}
