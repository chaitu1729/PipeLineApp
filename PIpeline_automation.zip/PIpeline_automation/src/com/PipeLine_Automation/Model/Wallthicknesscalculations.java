package com.PipeLine_Automation.Model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils.Collections;

public class Wallthicknesscalculations {
	/* pressure containment case Constants*/
	double SMYS=0;
	double E=1;
    double F=0.72;
    double tdf=1;
	/*hydro static test pressure case Constants*/
    double Fht=0.95;
    /*internal pressure burst Design case*/
    double Fd=0.9;
    double Fe=1;
    double Ft=1;
    /*Collapse due to external pressure case*/
    double Fo=0.6;
    /*Buckle propagation constants*/
    double Fp=0.8;
    /*Buckling Due to Combined Bending and External Pressure Case*/
    double Fc1=1;
    double Fc2=0.6;
    double F1=3.33;
    double F2=2;
	public Map<String,HashMap<String, Double>> pressureContainment(double internalPressure,double SMYS,double Od,double corrosionAllowance)
	{
		double thickness = 0;	
	    HashMap<String, Double> cas_e = new HashMap<String, Double>();
	    HashMap<String, HashMap<String, Double>> pcMap = new HashMap<String, HashMap<String, Double>>();
		thickness = ((internalPressure*Od)/(2*SMYS*F));
			thickness=thickness+corrosionAllowance;
			System.out.println("pressure containment "+thickness);
			cas_e.put("Installation", thickness+corrosionAllowance);
			cas_e.put("Operation", thickness);
		pcMap.put("30CFR250", cas_e);
	return pcMap;
	}

	public Map<String,HashMap<String, Double>> AsmeB318(double internalPressure,double SMYS,double Od,double density,double corrosionAllowance,double minDepth,double maxDepth,double densityOfTestFluid)
	{
		double thickness = 0;
		double extPressureMinDepth=0;
		double extPressureMaxDepth=0;
		double minExtPress=0;
		TreeMap<String,HashMap<String, Double>> psAPI = new TreeMap<String,HashMap<String, Double>>();
		extPressureMinDepth = densityOfTestFluid*minDepth;
		extPressureMaxDepth = densityOfTestFluid*maxDepth;
		double design_pressure_minDepth = internalPressure-((maxDepth-minDepth)*density);
		double design_pressure_maxDepth = internalPressure;
		double dp1=design_pressure_minDepth-extPressureMinDepth;
		double dp2=design_pressure_maxDepth-extPressureMaxDepth;
		minExtPress = Math.min(extPressureMaxDepth, extPressureMinDepth);
		HashMap<String, Double> cas_e = new HashMap<String, Double>();
				thickness=((Math.max(dp1,dp2))*Od/((2*SMYS*F*tdf)+(Math.max(dp1, dp2))));
					thickness=thickness+corrosionAllowance;
					System.out.println("AsmeB318 "+thickness);
				cas_e.put("Installation", thickness+corrosionAllowance);
				cas_e.put("Pperation", thickness);
				psAPI.put("ASMEB31.8", cas_e);
	return psAPI;
	}
	public Map<String,HashMap<String, Double>> hydrostaticTestPressure(double internalPressure,double SMYS,double Od,double corrosionAllowance,double airgap,double maxDepth,double density,double densityOfTestFluid)
	{
		double thickness = 0;	
	    HashMap<String, Double> cas_e = new HashMap<String, Double>();
	    HashMap<String, HashMap<String, Double>> pcMap = new HashMap<String, HashMap<String, Double>>();
	    double riserPressure = internalPressure-((airgap+maxDepth)*density);
	    double hydrostaticTestPressure = ((1.25*riserPressure))+(densityOfTestFluid*airgap);
		thickness = ((hydrostaticTestPressure*Od)/(2*SMYS*Fht));
			System.out.println("hydrostaticTestPressure "+thickness);
			cas_e.put("Installation", thickness+corrosionAllowance);
			cas_e.put("Operation", thickness);
		pcMap.put("HydrostaticTestPressure", cas_e);
	return pcMap;
	}
	public Map<String,HashMap<String, Double>> internalBurstPressure(double internalPressure,double SMYS,double tensileStrength,double minDepth,double maxDepth,double airGap,double density,double densityOfTestFluid,double corrosionAllowance,double Od)
	{
		double thickness_thick = 0;	
		double thickness_thin=0;
	    HashMap<String, Double> cas_e = new HashMap<String, Double>();
	    HashMap<String, HashMap<String, Double>> pcMap = new HashMap<String, HashMap<String, Double>>();
	    double riserPressure = internalPressure-((airGap+maxDepth)*density);
	    double hydrostaticTestPressure = (1.25*riserPressure)+(densityOfTestFluid*airGap);
	    double Pb=hydrostaticTestPressure/(Fd*Fe*Ft);
	    double rhs_thick= Math.exp((Pb/(0.45*(SMYS+tensileStrength))));
	    double rhs1_thick=Od/rhs_thick;
	    thickness_thick=(Od-rhs1_thick)/2;
	    
	    double rhs_thin= ((Pb/(0.9*(SMYS+tensileStrength))));
	    thickness_thin=rhs_thin*Od/(1+rhs_thin);
	    
	    double thickness=0;
	    
	    if((Od/thickness_thick)<=15)
	    {
	    	thickness=thickness_thick;
	    }
	    else if((Od/thickness_thin)>=15)
	    {
	    	thickness=thickness_thin;
	    }
	    System.out.println("internalBurstPressure "+thickness);
	    cas_e.put("Installation", thickness+corrosionAllowance);
		cas_e.put("Operation", thickness);
		pcMap.put("InternalBurstPressure", cas_e);
		return pcMap;
		
	}
	
	public Map<String,HashMap<String, Double>> collapseDueToExternalPressure(double internalPressure,double SMYS,double youngsModulus,double minDepth,double maxDepth,double airGap,double density,double densityOfWater,double corrosionAllowance,double Od)
	{
		 HashMap<String, Double> cas_e = new HashMap<String, Double>();
		 double thickness = 0;
		    HashMap<String, HashMap<String, Double>> pcMap = new HashMap<String, HashMap<String, Double>>();
		    double Pe2=(densityOfWater*maxDepth);
		    double Pe1 = (densityOfWater*minDepth);
		    double P_collapse_int2 = Pe2/Fo;
		    double P_collapse_int1 = Pe1/Fo;
		    double flush_collapse2 = Pe2/Fo;
		    double flush_collapse1 = Pe1/Fo;
		    double max_shut_down_pressure = (density*(maxDepth+airGap));
		    double min_shut_down_pressure = (density*(minDepth+airGap));
		    double maxShutDownDifferentialPressure=	(Pe2-max_shut_down_pressure)/Fo;
		    double minShutDownDifferentialPressure=	(Pe1-min_shut_down_pressure)/Fo;
		    ArrayList<Double> thicknesses = new ArrayList<Double>();
		    
		    ArrayList<Double> stage = new ArrayList<Double>();
		    stage.add(Math.max(P_collapse_int2, P_collapse_int1));
		    stage.add(Math.max(flush_collapse2, flush_collapse1));
		    stage.add(Math.max(maxShutDownDifferentialPressure, minShutDownDifferentialPressure));
		    for(int i=0;i<stage.size();i++)
		    {
		    	thicknesses.add(getCollapseDueToExternalPressure(SMYS,youngsModulus,Od,0.3,stage.get(i)));
		    }
		    thickness =  java.util.Collections.max(thicknesses);
		    System.out.println("collapseDueToExternalPressure "+thickness);
		    cas_e.put("Installation", thickness+corrosionAllowance);
			cas_e.put("Operation", thickness);
			pcMap.put("CollapseExternalPressure", cas_e);
			return pcMap;
	}
	
	private double getCollapseDueToExternalPressure(double Ys,double youngsMod,double Od,double poissonsRatio,double lhsPressure)
	{
		boolean realCheck=false;
		double t=1;
		double Do=Od;
		double u=poissonsRatio;
		while (!realCheck) {
		double res1=0;
			double ucommon=Math.pow(u, 4)-(2*Math.pow(u, 2))+1;
			double 	d1_commona=(Math.pow(Ys, 2)*Math.pow(t, 2))/(Math.pow(Do, 2));
			double d1_commonb=Math.pow(youngsMod, 2)*Math.pow(t, 6)/(Math.pow(Do, 6)*ucommon);
			double denu1=(Math.pow(u, 2))-1;
			double d1=(Math.pow(Do, 6))*((Math.pow(d1_commona+d1_commonb, (3/2))))*denu1;
			double den1sum=d1_commona+d1_commonb;
			double den1sum32=den1sum*Math.sqrt(den1sum);// pow 3/2
			double den1total=den1sum32*Math.pow(Do, 6)*denu1;
			
			double den2sum=den1sum;
			double den2sqrt=Math.sqrt(den2sum);
			double den2total=den2sqrt*Math.pow(Do, 4)*denu1;
			
			double den3u=Math.pow(u, 6)-(3*Math.pow(u, 4))+(3*Math.pow(u, 2))-1;
			double den3sum32=den1sum32;
			double den3total=(Math.pow(Do, 10))*den3sum32*den3u;
			
			
			double num1=2*Math.pow(Ys, 3)*Math.pow(t, 5)*youngsMod;
			double num2=8*youngsMod*Ys*Math.pow(t, 3);
			double num3 = 6*Math.pow(youngsMod, 3)*Ys*Math.pow(t, 9);
			
			double fdash=(num1/den1total)-(num2/den2total)+(num3/den3total);
			
			double numoft=(Math.pow((t/Do), 4)*4*Ys*youngsMod)/(1-(Math.pow(u, 2)));
			double denoft=Math.sqrt(Math.pow((2*Ys*(t/Do)), 2)+Math.pow((2*youngsMod*(Math.pow((t/Do), 3)/(1-(Math.pow(u, 2))))),2));
			double foft=(numoft/denoft)-lhsPressure;
			res1=t-(foft/fdash);
			double Var = Math.abs(t-res1);
		if(Var<=0.000001)
		{
			realCheck=true;	
		}
		t=res1;
		
	}
		System.out.println(t);
	return t;
	}

	public  Map<String,HashMap<String, Double>> collapseDueToCombinedBendingExtPressure(double yieldStress,double youngsModulus,double ovality,double strain_ins_bending,double strain_opr_bending,double oD,double densityOfWater,double density,double maxDepth,double minDepth,double airGap,double corrosionAllowance)
	{
		HashMap<String, HashMap<String, Double>> pcMap = new HashMap<String, HashMap<String, Double>>();
		double Pe2=(densityOfWater*maxDepth);
	    double Pe1 = (densityOfWater*minDepth);
	    double Psd2 = (density*(maxDepth+airGap));
	    double Psd1 = (density*(minDepth+airGap));
	    double dPsd2 = Pe2-Psd2;
	    double dPsd1 = Pe1-Psd1;
	    
	    
	    ArrayList<String> cases = new ArrayList<String>();
	    ArrayList<Double> thicknesses = new ArrayList<Double>();
	    cases.add("ins");
	    cases.add("opr");
	    cases.add("sdown");
	    for(int i=0;i<cases.size();i++)
	    {
	    	double pressure =0;
	    	if(cases.get(i)!=null && cases.get(i).equalsIgnoreCase("ins") || cases.get(i).equalsIgnoreCase("opr"))
	    	{
	    		pressure =  Math.max(Pe1, Pe2);
	    	}
	    	else
	    	{
	    		pressure = Math.max(dPsd2,dPsd1);
	    	}
	    	thicknesses.add(getCollapseDueToCombinedBendingExternalPressure(yieldStress, youngsModulus, oD, 0.3,ovality, cases.get(i), pressure));
	    }
	   double  thickness=0;
	    HashMap<String, Double> cas_e = new HashMap<String, Double>();
	    thickness =  java.util.Collections.max(thicknesses);
	    System.out.println("collapseDueToCombinedBendingExternalPressure "+thickness);
	    cas_e.put("Installation", thickness+corrosionAllowance);
		cas_e.put("Operation", thickness);
		pcMap.put("collapseDueToCombinedBendingExtPressure", cas_e);
		return pcMap;
	    
	}

	private double getCollapseDueToCombinedBendingExternalPressure(double Ys,double youngsMod,double Od,double poissonsRatio,double ovality,String check,double pressure)
	{
		boolean realCheck = false;
		double E=youngsMod;
		double t=1;
		double Do=Od;
		double u=poissonsRatio;
		double fc1=Fc1;
		double f1=F1;
		ovality = 0.0075;
		System.out.println("inital t "+t);
		double ei=0.0015;
		ei=ei*f1;
		double eo=0.0015;
		eo=eo*2;
		double e1=0;	
		if(check!=null && check.equalsIgnoreCase("ins"))
		{
			e1=ei;
		}
		else if(check!=null && check.equalsIgnoreCase("opr"))
		{
			e1=eo;
			fc1=Fc2;
		}
		else if(check!=null && check.equalsIgnoreCase("sdown"))
		{
			e1=eo;
			fc1=Fc2;
		}
		double gdelta = 1/(1+(20*ovality));
		while (!realCheck) {
			double res1=0;
		double den3=Math.pow(Do, 3)*(Math.sqrt((Math.pow(Ys, 2)*Math.pow(t, 2)/Math.pow(Do, 2))+(Math.pow(E, 2)*Math.pow(t, 6)/((Math.pow(Do, 6))*((Math.pow(u, 4))-(2*Math.pow(u, 2))+1)))))*((Math.pow(u, 2))-1);
		double part3 = ((12*E*Ys*fc1)*Math.pow(t, 2)*e1)/den3;
		double constant = (Math.sqrt((Math.pow(Ys, 2)*Math.pow(t, 2)/Math.pow(Do, 2))+(Math.pow(E, 2)*Math.pow(t, 6)/((Math.pow(Do, 6))*((Math.pow(u, 4))-(2*Math.pow(u, 2))+1)))));
		double const32 = Math.pow(constant, 2)*constant;
		double den4 = Math.pow(Do, 9)*const32*((Math.pow(u, 6))-(3*(Math.pow(u, 4)))+(3*(Math.pow(u, 2)))-1);
		double part4 = (12*Math.pow(E, 3)*Ys*fc1*Math.pow(t, 8)*e1)/den4;
		
		double den6 = Math.pow(Do, 5)*const32*((Math.pow(u, 2))-1);
		double part6 = 4*E*Math.pow(Ys, 3)*fc1*Math.pow(t, 4)*e1/den6;
		
		double den5 = Math.pow(Do, 6)*const32*((Math.pow(u, 2))-1);
		double part5 = 2*E*Math.pow(Ys, 3)*gdelta*fc1*Math.pow(t, 5)/den5;
		double den2 = constant*((Math.pow(u, 2))-1)*Math.pow(Do, 4);
		double part2 = 8*E*Ys*gdelta*fc1*Math.pow(t, 3)/den2;
		
		double den1 = const32*Math.pow(Do, 10)*((Math.pow(u, 6))-(3*(Math.pow(u, 4)))+(3*(Math.pow(u, 2)))-1);
		double part1=6*Math.pow(E, 3)*Ys*gdelta*fc1*Math.pow(t, 9)/den1;
		
		double fdash=part1-part2+part3-part4+part5-part6;
		double numoft=(Math.pow((t/Do), 4)*4*Ys*E)/(1-(Math.pow(u, 2)));
		double denoft=Math.sqrt(Math.pow((2*Ys*(t/Do)), 2)+Math.pow((2*E*(Math.pow((t/Do), 3)/(1-(Math.pow(u, 2))))),2));
		
		double foft=(((gdelta)-(e1/(t/(2*Do))))*fc1*numoft/denoft)-pressure;
		
		res1 = t-(foft/fdash);
		if(t-res1<0.00001)
		{
			realCheck=true;
		}
		t=res1;
		}
		
	return t;
	}
	
	public  Map<String,HashMap<String, Double>> BucklePropagation(double yieldStress,double youngsModulus,double oD,double densityOfWater,double density,double maxDepth,double minDepth,double airGap,double corrosionAllowance)
	{
		HashMap<String, HashMap<String, Double>> pcMap = new HashMap<String, HashMap<String, Double>>();
		double Pe2=(densityOfWater*maxDepth);
	    double Pe1 = (densityOfWater*minDepth);	
	    double Psd2 = (density*(maxDepth+airGap));
	    double Psd1 = (density*(minDepth+airGap));
	    double dPsd2 = Pe2-Psd2;
	    double dPsd1 = Pe1-Psd1;
	    double thickness = 0;
	    double a = 1/2.4;
	    double tflush =(Math.pow((Math.max(Pe1, Pe2)/(24*yieldStress*Fp)),a))*oD;
	    double tshutDown = (Math.pow((Math.max(dPsd2, dPsd1)/(24*yieldStress*Fp)),a))*oD;
	    HashMap<String, Double> cas_e = new HashMap<String, Double>();
	    thickness=Math.max(tflush, tshutDown);
	    cas_e.put("Installation", thickness+corrosionAllowance);
		cas_e.put("Operation", thickness);
		pcMap.put("bucklePropagation", cas_e);
		
	return pcMap;
	}
	
}
