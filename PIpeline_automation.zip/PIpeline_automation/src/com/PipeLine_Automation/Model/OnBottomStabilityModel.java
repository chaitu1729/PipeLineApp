package com.PipeLine_Automation.Model;

import java.util.Map;
import java.util.TreeMap;

public class OnBottomStabilityModel {
	
	
	public TreeMap<String,TreeMap<String, Double>> getData(double submergedWeight,double density,double currVelocity,double refHeight,double SpreadingFactor,double bearingAngle,double spectralPeakPeriod,double effDiameter,
			double fricFactor,double roughness,double grainSize,double jonswrapSpectrum,double significantWaveHeight,double viscosity,String designCase,double depth)
			{
		double accelerationDueToGravity = 32.174;
		double waterDensity = 62.4;
		double curVelPerpendicularToPipe=currVelocity*Math.sin(bearingAngle);
		double avgCurVelonPipe = curVelPerpendicularToPipe*(1/(Math.log((refHeight/roughness)+1)))*(((1+(roughness/effDiameter))*(Math.log((effDiameter/roughness)+1)))-1);
		double waveTimeperiod = Math.sqrt((depth/accelerationDueToGravity));
		double xfig21=waveTimeperiod/spectralPeakPeriod;
		double yfig21=0;
		if(xfig21>0.5)
		{
			yfig21=0.000001;
		}
		//462.08x6 - 728.92x5 + 400.8x4 - 79.382x3 + 1.1018x2 - 0.6884x + 0.5039
		else if(xfig21<=0.5 && jonswrapSpectrum==5){
		yfig21 = (462.08*Math.pow(xfig21, 6)) - (728.92*Math.pow(xfig21, 5)) + (400.8*Math.pow(xfig21,4)) -(79.382*Math.pow(xfig21,3)) + (1.1018*Math.pow(xfig21,2)) - (0.6884*Math.pow(xfig21,1)) + 0.5039;
		}
		//369.79x6 - 550.28x5 + 268.34x4 - 32.962x3 - 6.4013x2 - 0.254x + 0.4991
		else if(xfig21<=0.5 && jonswrapSpectrum==3.3){
			yfig21 = (369.79*Math.pow(xfig21, 6)) - (550.28*Math.pow(xfig21, 5)) + (268.34*Math.pow(xfig21,4)) -(32.962*Math.pow(xfig21,3)) - (6.4013*Math.pow(xfig21,2)) - (0.254*Math.pow(xfig21,1)) + 0.4991;
			}
		//209.18x6 - 256.76x5 + 64.511x4 + 31.995x3 - 15.109x2 + 0.0201x + 0.4959
		else if(xfig21<=0.5 && jonswrapSpectrum==1){
			yfig21 = (209.18*Math.pow(xfig21, 6)) - (256.76*Math.pow(xfig21, 5)) + (64.511*Math.pow(xfig21,4)) +(31.995*Math.pow(xfig21,3)) - (15.109*Math.pow(xfig21,2)) + (0.0201*Math.pow(xfig21,1)) + 0.4959;
			}
		double yfig22 = 1.2599*xfig21 + 0.7744;
		double significantWaveVelPerpToPipe = (significantWaveHeight/waveTimeperiod)*yfig21*SpreadingFactor;
		double maxWaveVel = significantWaveVelPerpToPipe*Math.sin(bearingAngle);
		double zeroUpCrossingPeriod = yfig22*spectralPeakPeriod;
		double maxWaveAcc = 2*Math.PI*maxWaveVel/zeroUpCrossingPeriod;
		double reynoldsNum =  (maxWaveVel+avgCurVelonPipe)*effDiameter/viscosity;
		double keuleganCarpentarNumber = maxWaveVel*waveTimeperiod/effDiameter;
		double currToWaveRatio = avgCurVelonPipe/maxWaveVel;
		TreeMap<String,TreeMap<String,Double>> finalMap = new TreeMap<String, TreeMap<String,Double>>();
		TreeMap<String,Double> subMap = new TreeMap<String, Double>();
				
		double calibrationFactor =1; // formulate it
		double Ws2 = 0;
		double criticalPhaseAngle = 0;
		double i=0;
		double CL=0.9;
		double CD=0.7;
		double CM=3.29;
		while(i<=180)
		{
		double ws2=0;
		double theta = i/2;
		double Fl = 0.5*waterDensity*effDiameter*CL*(Math.pow(((maxWaveVel*(Math.cos(theta*Math.PI/180)))+avgCurVelonPipe),2))/accelerationDueToGravity;
		double Fd = 0.5*waterDensity*effDiameter*CD*Math.abs((maxWaveVel*Math.cos(theta*Math.PI/180))+avgCurVelonPipe)*((maxWaveVel*Math.cos(theta*Math.PI/180))+avgCurVelonPipe)/accelerationDueToGravity;
		double Fi = waterDensity*(Math.PI/4)*Math.pow(effDiameter, 2)*CM*maxWaveAcc*Math.sin(theta*Math.PI/180)/accelerationDueToGravity;
		double Ws1 = (Fd+Fi+(fricFactor*Fl))*calibrationFactor/fricFactor;
		if(Ws1>Ws2)
		{
			Ws2=Ws1;
		}
		if(Ws2==Ws1)
		{
			criticalPhaseAngle = i/2;
		}
		i=i+0.5;
		}
		
		double liftForce = 	0.5*waterDensity*effDiameter*CL*(Math.pow(((maxWaveVel*(Math.cos(criticalPhaseAngle*Math.PI/180)))+avgCurVelonPipe),2))/accelerationDueToGravity;
		double dragForce = 0.5*waterDensity*effDiameter*CD*Math.abs((maxWaveVel*Math.cos(criticalPhaseAngle*Math.PI/180))+avgCurVelonPipe)*((maxWaveVel*Math.cos(criticalPhaseAngle*Math.PI/180))+avgCurVelonPipe)/accelerationDueToGravity;
		double inertiaForce = waterDensity*(Math.PI/4)*Math.pow(effDiameter, 2)*CM*maxWaveAcc*Math.sin(criticalPhaseAngle*Math.PI/180)/accelerationDueToGravity;
		double requiredWeight = (dragForce+inertiaForce+(fricFactor*liftForce))*calibrationFactor/fricFactor;
		double unityCheck = requiredWeight/submergedWeight;
		double verticalStabilityCheck = submergedWeight/liftForce;
		double horizontalStabilityCheck = ((submergedWeight/calibrationFactor)-liftForce)*(fricFactor/(dragForce+inertiaForce));
		subMap.put("Vertical Stability check",verticalStabilityCheck);
		subMap.put("Horizontal Stability check",horizontalStabilityCheck);
		subMap.put("Unity Check", unityCheck);
		Double flag=0.0;
		if(unityCheck<1)
		{
			flag=1.0;
		subMap.put("Notes", flag);
		}
		else{
			subMap.put("Notes", flag);
		}
		finalMap.put(designCase,subMap);
			
			return finalMap;
			}
	

}
