var data = {
  labels: ['A', 'B', 'C'],
  series: [[
    {x: undefined, y: 10},
    {x: undefined, y: 8},
    {x: undefined, y: 14}
  ]]
};
